# Amber skin for NINJAMplus

I read your actual `PluginEditor.cpp` (628 KB, ~15,150 lines) and used
your real theme system — background image + bitmap fader cap + colour
presets for knobs — the same mechanism your other skins (Brushed Metal,
Sand 1, etc.) use. Here's what it told me:

## How skins actually work in your app

Skins are **not** compiled into the binary. `PluginEditor.cpp` scans a
`textures/` folder next to the executable (or `Resources/textures/` on
mac/Linux bundles) for subfolders. Any subfolder containing a `bg.*` file
shows up in the "Skin" dropdown (the one currently showing "Brushed
Metal ▾"). Each folder can optionally contain:

| File          | Purpose                                                            |
|---------------|---------------------------------------------------------------------|
| `bg.png`/`bg.jpg`/`bg.mp4` | Background, stretched to fill the window (`fillDestination`) |
| `fknob.png`   | Optional bitmap for the fader thumb (overrides colour theming)     |
| `rknob.png`   | Optional bitmap for rotary knobs (overrides colour theming)        |
| `skin.cfg`    | Text file setting theme colours (see below)                        |

If `fknob.png`/`rknob.png` are absent, faders/knobs are vector-drawn and
tinted using `skin.cfg`'s `Faders:`/`Knobs:` preset name, run through
`colourFromPresetName()` (around line 7980 of your file). That function
only recognises a fixed list: gold, grey, sand, yellow, orange, red,
blue, pink, purpleblue, black, cream, white. **"Amber" isn't one of
them**, so you have two options (below) for the colour presets.

## This package ships a real `fknob.png`, deliberately no `rknob.png`

You asked me to use the actual theme system (background/faders/knobs),
so I did — with one deliberate exception, because I traced a real
inconsistency in how your code applies `rknob.png`:

- **`fknob.png` (shipped):** `FaderLookAndFeel::drawLinearSlider` uses
  the image for *every* linear slider, any size, no exceptions. 100%
  safe. I built `Amber/fknob.png` at 4x resolution (88×168, matching
  the ~22×42 box the app draws it into with `RectanglePlacement::centred`)
  — a flat dark cap with the amber grip-line accent from the earlier
  mockups.

- **`rknob.png` (deliberately not shipped):** `CustomKnobLookAndFeel::
  drawRotarySlider` only uses the bitmap when
  `knobMinDim >= 40 || forceImageKnob || matchReleaseStyle`. Your REV/DLY
  knobs render smaller than that (only the big Release knob clears 40px
  by default), so they'd fall back to the vector path. And in
  `loadControlImages()`, the moment `radioKnobImage.isValid()` is true,
  the `Knobs:` line in `skin.cfg` is **skipped entirely** — so those
  smaller vector-fallback knobs would reset to plain grey instead of
  picking up the theme colour. Net effect of shipping `rknob.png`:
  Release knob turns amber, REV/DLY knobs turn grey — an inconsistent
  skin.
  Keeping `rknob.png` out and setting `Knobs: amber` (or `orange`)
  instead means the vector renderer tints **every** knob size
  consistently, Release included. If you'd rather have real bitmap
  knob art anyway and are fine special-casing REV/DLY (e.g. setting the
  `matchReleaseStyle` property on those sliders so they also qualify
  for the image), say so and I'll build `rknob.png` too plus the
  one-line property change.

## Option A — exact amber, one-line source patch (recommended)

In `PluginEditor.cpp`, find `colourFromPresetName()`:

```cpp
static juce::Colour colourFromPresetName(const juce::String& preset, const juce::Colour& fallback)
{
    const auto key = normaliseColourPresetName(preset);
    if (key == "gold") return juce::Colour(0xffb8860b);
    if (key == "grey" || key == "gray") return juce::Colour(0xff909090);
    if (key == "sand" || key == "sandcolour" || key == "sandcolor") return juce::Colour(0xffc2b280);
    if (key == "yellow") return juce::Colour(0xffffd700);
    if (key == "orange") return juce::Colour(0xffff8c00);
    if (key == "red") return juce::Colour(0xffdc143c);
```

Add one line right after the `orange` case:

```cpp
    if (key == "orange") return juce::Colour(0xffff8c00);
    if (key == "amber") return juce::Colour(0xfff2a93b);   // <-- add this line
    if (key == "red") return juce::Colour(0xffdc143c);
```

That's the entire code change. It's additive (one new `if`), doesn't
touch any existing preset, and doesn't change any function signature —
every other skin keeps working exactly as before. Rebuild, and
`skin.cfg`'s `Knobs: amber` / `Faders: amber` (already set in the file
below) will resolve to the true amber `#F2A93B` used in the mockups.

## Option B — zero source changes

Don't patch anything. Just open `Amber/skin.cfg` and change:

```
Knobs: orange
Faders: orange
```

`orange` (`0xffff8c00`) is the closest built-in preset — a bit more
saturated/red than the amber in the mockups, but real and no rebuild
of `colourFromPresetName` needed.

## Installation

1. Copy the `Amber/` folder from this delivery into your repo's
   `textures/` directory, so you end up with `textures/Amber/`
   sitting next to `textures/Brushed Metal 1/` etc.
2. (Recommended) apply the one-line patch above.
3. Rebuild (or just relaunch if you're running an unpacked build that
   reads `textures/` at runtime — no CMake changes needed, this isn't
   a compiled asset).
4. Open the skin dropdown — "Amber" will appear alphabetically in the
   list, pull it up.

## What's set in skin.cfg

- `Window Colour: 20242C` — panel background tint (used app-wide when set)
- `MenuBar Colour: 1B1E25` — title bar
- `Button Colour: 262B34` — button fill
- `Metronome Colour: F2A93B` — metronome flash uses the amber accent too
- `Knobs:` / `Faders:` — see options A/B above

## What I did *not* change

I did not touch `drawLinearSlider`, `drawRotarySlider`,
`FaderLookAndFeel`, or `CustomKnobLookAndFeel` — those already produce
a good result once `faderThemeColour`/`knobThemeColour` are set via
`skin.cfg`, so there was no need to touch the rendering code, which
lowers the risk of this patch breaking anything else.

If you'd like the fader thumb and knobs to use actual bitmap art
instead of the vector+tint rendering (matching the flatter, more
"designed" look of the mockups pixel-for-pixel), send me your
`textures/Skin Template/` folder (or any existing `fknob.png`/
`rknob.png` for reference dimensions) and I'll produce matching
`fknob.png`/`rknob.png` for the Amber folder too.
