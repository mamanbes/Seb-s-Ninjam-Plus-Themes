# Vinyl & Wood — studio theme for NINJAMplus

Warm analog-studio aesthetic: walnut wood-grain background, a real
chrome console-style fader cap, and a vinyl record knob complete with
a tonearm pointer.

## What's in the folder

- `Vinyl & Wood/bg.png` — procedural walnut wood grain (wavy fibre
  lines with a bit of domain-warping so it doesn't look like a
  repeating pattern), a soft centred "studio light" glow, two plank
  seams, and a single subtle knot for character
- `Vinyl & Wood/fknob.png` — a chrome fader cap: brushed-metal banded
  gradient, horizontal grip ridges top and bottom (like real fader
  caps have), and the classic red centre indicator line you'd see on
  an SSL/Neve-style console strip
- `Vinyl & Wood/rknob.png` — a vinyl record: visible concentric
  grooves, a warm amber centre label, a glossy sweep highlight, and a
  tonearm-and-headshell pointer reaching from the spindle to the edge.
  Drawn in its neutral "straight up" pose — the app rotates the whole
  bitmap at runtime, so the tonearm sweeps around like a real arm
  tracking the groove as you turn the knob
- `Vinyl & Wood/skin.cfg` — warm brown window/button colours, amber
  metronome flash

## The usual rknob.png caveat

Same note as every skin I've shipped a real `rknob.png` for: your
Release knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will show the record;
REV/DLY (smaller) will likely fall back to a plain vector knob, and
since `rknob.png` is present, `skin.cfg`'s `Knobs:` line is skipped,
so that fallback will be plain grey rather than gold. Set
`matchReleaseStyle` (or `forceImageKnob`) on those sliders if you want
them to show the record too — or, if you're up for revisiting the
`PluginEditor.cpp` size patch from the UFO theme's README, raising the
`revKnobSize`/`dlyKnobSize` cap past 40 fixes this automatically for
every image-based skin, not just this one.

## Installation

Copy `Vinyl & Wood/` into `textures/`, rebuild, pick "Vinyl & Wood"
from the skin dropdown. No source patch needed for colours — both
bitmaps are present so `colourFromPresetName()` isn't consulted for
this skin.
