# Mr. Peaches II — theme for NINJAMplus

The sequel: same peach colour theme, now with a black/grey bass
guitar and a friend for Mr. Peaches, both centred with the wordmark.

## What changed from the first Mr. Peaches skin

1. **Bass guitar is black/grey now** — black headstock and body
   (with a subtle glossy highlight sweep), grey neck and fretboard,
   silver tuning pegs and hardware. Kept two small peach-coloured fret
   markers as a subtle tie-back to the theme rather than going fully
   monochrome.
2. **Peach and text are centred** — the mascot(s) and the "MR.
   PEACHES" wordmark are now aligned on the same central vertical axis
   as the whole background, rather than off to one side.
3. **A second peach joins the background** — two mascots side by side:
   the original winking/tongue-out peach, and a new second peach with
   a plain friendly two-eyed grin for a bit of visual variety between
   the pair.

## What's in the folder

- `Mr. Peaches II/bg.png` — same warm peach-to-coral gradient as
  before, now with two peach mascots centred side by side and the
  wordmark centred above them
- `Mr. Peaches II/fknob.png` — the bass guitar, recoloured black/grey
  as described above
- `Mr. Peaches II/rknob.png` — unchanged from the original Mr. Peaches
  skin (the peach knob you already liked)
- `Mr. Peaches II/skin.cfg` — same warm peach/coral window and button
  colours as the original

## Same notes as before, carried over

This is still a light background (peach is inherently a light,
warm colour) — same legibility reasoning as the original Mr. Peaches
README applies. And the same `rknob.png` caveat applies too: the
Release knob will show the peach, REV/DLY may fall back to plain grey
below the `knobMinDim >= 40` threshold unless you set
`matchReleaseStyle`/`forceImageKnob` on those sliders, or raise the
`revKnobSize`/`dlyKnobSize` cap per the UFO theme's README.

## Installation

Copy `Mr. Peaches II/` into `textures/`, rebuild, pick "Mr. Peaches II"
from the skin dropdown. No source patch needed for colours.
