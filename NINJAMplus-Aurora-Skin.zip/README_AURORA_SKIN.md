# Aurora — glassmorphism theme for NINJAMplus

A genuinely different one this time: mid-tone "in between light and dark"
background, and frosted-glass faders/knobs with a pink → purple → blue
gradient edge that glows. Same real theme system as the others
(background + bitmap faders + bitmap knobs), no source patch required
for colour this time (see why below).

## The brief, and how I read it

- **"In between light and dark"** — the background is a genuine mid-grey
  (not dark-charcoal like Amber, not near-white like Daylight), leaning
  just slightly toward the darker half of that middle range on purpose:
  your app's labels render in light-coloured text, so a mid-grey that
  leans dark keeps that text legible without depending on how strong
  the label outline effect actually is (I still haven't seen that class
  — see the very first Amber README for why).
- **"Crazy but effective" knobs/faders** — the fader cap has a pink-
  purple-blue gradient glowing edge around a frosted glass body. The
  rotary knob goes further: a full conic (rainbow-style) gradient ring
  glowing around a frosted glass face, with a plain white pointer/tip
  for max contrast against all that colour. Both stay unambiguously
  readable as "the thing you drag/turn" — the gradient is the flair,
  the shape/pointer is what your eye actually tracks.
- **"More transparent"** — worth being precise here. What I actually
  built is a *glassmorphism* look: the fader cap and knob face are
  semi-transparent PNG layers (frosted white at ~50% alpha) so they
  read as "glass" sitting over the dark rail/track. That's real alpha
  transparency, and it's exactly what the existing `fknob.png`/
  `rknob.png` mechanism supports well.
  What I did **not** do — and want to flag clearly rather than imply
  it's included — is make the actual app *window* see-through to
  whatever's behind it on your desktop. `bg.png` is drawn with
  `RectanglePlacement::fillDestination` over the full window every
  time, opaque, by design (that's in the `.cpp` you gave me) — feeding
  it a transparent PNG wouldn't reveal your desktop, it would likely
  just show black or whatever's underneath the paint call, and true
  OS-level window transparency would mean calling
  `setOpaque(false)` on the top-level window/editor and enabling
  transparency support at the window-creation level — a real code
  change, not a texture, and one that behaves inconsistently for
  VST3/AU plugin windows hosted inside a DAW (the host, not JUCE,
  often owns that window). I didn't want to quietly skip half the ask,
  so: this delivers the "glassy" *look*, not desktop-see-through.

## What's in the folder

- `Aurora/bg.png` — mid-tone blue-grey gradient with three soft, blurred
  colour blobs (pink / purple / blue) for that aurora-glass tint, plus
  fine grain for texture
- `Aurora/fknob.png` — frosted glass fader cap, glowing gradient edge,
  glowing gradient centre grip line
- `Aurora/rknob.png` — frosted glass rotary knob, full conic rainbow
  gradient ring with glow, plain white pointer for contrast (neutral
  pose: pointer straight up, since the app rotates the whole bitmap at
  runtime for the current value)
- `Aurora/skin.cfg` — mid-tone window/button/menubar colours, pink
  metronome flash

## The usual rknob.png caveat

Same as every skin I've shipped a real `rknob.png` for: your Release
knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will use this bitmap;
REV/DLY (smaller) likely won't and will fall back to a plain vector
knob instead. Since `rknob.png` is present, `skin.cfg`'s `Knobs:` line
is skipped too, so that fallback will be plain grey, not themed. Set
`matchReleaseStyle` (or `forceImageKnob`) on those sliders in
`PluginEditor.h`/`.cpp` if you want them to use the bitmap too — I
still don't have that header, so I can't give you the exact line.

## Installation

Copy `Aurora/` into `textures/`, rebuild, pick "Aurora" from the skin
dropdown. No source patch needed for colours this time — both bitmaps
are present so `colourFromPresetName()` isn't consulted for this skin
at all.
