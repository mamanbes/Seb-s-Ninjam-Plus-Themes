# Jungle — theme for NINJAMplus

Dense canopy background, a monkey hanging from a vine as the fader,
and a monkey face (tail doubling as the pointer) as the knob.

## What's in the folder

- `Jungle/bg.png` — dark jungle-green gradient, eight large tropical
  leaf silhouettes framing the edges (like looking up through canopy),
  three hanging vines with little leaf nodes, and a few soft warm
  dappled-sunlight glows
- `Jungle/fknob.png` — a monkey hanging one-armed from a vine at the
  top of the fader box, tail curled, other arm dangling, legs kicked
  up — cartoon proportions consistent with the other character-based
  skins (Silly, UFO, Jam In Peace)
- `Jungle/rknob.png` — a monkey face: big round ears, light muzzle
  patch, simple friendly expression. The tail curls up from behind the
  head in its neutral "straight up" pose — the app rotates the whole
  bitmap at runtime, so the tail sweeps around as the pointer, same
  trick as the alien's antenna and the record's tonearm
- `Jungle/skin.cfg` — deep green window/button colours, a warm
  yellow-green metronome flash

## The usual rknob.png caveat

Same note as the last several skins with a real `rknob.png`: the
Release knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will show the monkey
face; REV/DLY (smaller) will likely fall back to a plain vector knob,
and since `rknob.png` is present, `skin.cfg`'s `Knobs:` line is
skipped, so that fallback will be plain grey. Fix is
`matchReleaseStyle`/`forceImageKnob` on those two sliders, or the
reusable `revKnobSize`/`dlyKnobSize` cap increase from the UFO theme's
README.

## Installation

Copy `Jungle/` into `textures/`, rebuild, pick "Jungle" from the skin
dropdown. No source patch needed for colours — both bitmaps are
present so `colourFromPresetName()` isn't consulted for this skin.
