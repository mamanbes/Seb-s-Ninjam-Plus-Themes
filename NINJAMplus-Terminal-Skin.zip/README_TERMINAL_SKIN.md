# Phosphor Terminal skin for NINJAMplus

Same real theme system as the Amber skin: `textures/Terminal/` with
`bg.png` (CRT phosphor glow + vignette + faint scanlines), `fknob.png`
(a real bitmap fader cap — HUD corner brackets + glowing green grip
bar), and `skin.cfg`. No `rknob.png`, for the same reason as before:
shipping one would make the big Release knob green while the smaller
REV/DLY knobs silently fall back to plain grey (see the Amber README
for the full trace through `CustomKnobLookAndFeel`/`loadControlImages`
if you want the details again). Skipping it and using the `Knobs:`
colour preset instead keeps every knob size consistent.

## Colour preset patch

Like "amber", **"green" isn't a preset `colourFromPresetName()`
recognises** (list is: gold, grey, sand, yellow, orange, red, blue,
pink, purpleblue, black, cream, white). Same function, same fix —
if you already added the `amber` case for the previous skin, just
add one more line next to it:

```cpp
static juce::Colour colourFromPresetName(const juce::String& preset, const juce::Colour& fallback)
{
    const auto key = normaliseColourPresetName(preset);
    if (key == "gold") return juce::Colour(0xffb8860b);
    if (key == "grey" || key == "gray") return juce::Colour(0xff909090);
    if (key == "sand" || key == "sandcolour" || key == "sandcolor") return juce::Colour(0xffc2b280);
    if (key == "yellow") return juce::Colour(0xffffd700);
    if (key == "orange") return juce::Colour(0xffff8c00);
    if (key == "amber") return juce::Colour(0xfff2a93b);   // <-- from the last skin
    if (key == "green") return juce::Colour(0xff3cff6e);   // <-- add this line too
    if (key == "red") return juce::Colour(0xffdc143c);
```

Zero-code fallback: set `Knobs: blue` / `Faders: blue` in `skin.cfg`
instead — closest built-in hue, not a real phosphor-green match.

## Installation

Same as before — copy `Terminal/` into your repo's `textures/`
directory (sibling of `Amber/`, `Brushed Metal 1/`, etc.), apply the
patch line (or don't), rebuild, pick "Terminal" from the skin dropdown.

## Palette used

- Background: near-black with a very subtle green phosphor glow and
  faint horizontal scanlines
- `Window Colour: 0A120A` / `MenuBar Colour: 060A06` / `Button Colour: 0D160D`
- `Metronome Colour: 3CFF6E` — the beat flash pulses in the same green,
  reads like a heartbeat blip on an oscilloscope
- Fader cap: dark panel, thin green outline, HUD corner brackets,
  glowing green grip bar
