# Silly — the funny theme for NINJAMplus

Exactly what it says: a middle-finger fader and a googly psychedelic
eyeball knob, on a playful comic-halftone background, kept just
restrained enough to still be nice to look at.

## What's in the folder

- `Silly/bg.png` — mid-tone violet-to-teal gradient with a soft comic-
  book halftone dot pattern (fading out from one corner, kept low-
  opacity on purpose) and a light scatter of confetti flecks. Same
  legibility reasoning as the other mid-tone themes: dark enough that
  your light-coloured text stays readable, colourful enough to feel fun.
- `Silly/fknob.png` — a cartoon fist with the middle finger raised.
  Cartoon-yellow "skin" (not a realistic tone, keeps it silly rather
  than crude), a hot-pink fingernail as the "crazy colour" accent, and
  a little striped wristband for good measure. Reads clearly even at
  the small size it renders at in the actual fader track.
- `Silly/rknob.png` — a googly eyeball with a psychedelic rainbow-ring
  iris, a cartoon sparkle highlight, and a few doodled eyelashes. Drawn
  in its neutral pose gazing straight up — since the app rotates the
  whole bitmap at runtime to reflect the slider's value, the eye will
  visibly "look around" the dial as you turn the knob. That's a happy
  accident of how this app's rotary rendering works, not something I
  had to fake — it just falls out of using an eye as the artwork.
- `Silly/skin.cfg` — dark violet window/button colours, hot-pink
  metronome flash

## The usual rknob.png caveat

Same note as every skin I've shipped a real `rknob.png` for: the
Release knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will show the eyeball;
REV/DLY (smaller) likely won't and will fall back to a plain vector
knob, and since `rknob.png` is present, `skin.cfg`'s `Knobs:` line is
skipped, so that fallback will be plain grey rather than themed. If
you want the eye on every knob regardless of size, set
`matchReleaseStyle` (or `forceImageKnob`) to `true` wherever those
sliders are constructed in `PluginEditor.h`/`.cpp` — still don't have
that header, so I can't hand you the exact line.

## Installation

Copy `Silly/` into `textures/`, rebuild, pick "Silly" from the skin
dropdown. No source patch needed — both bitmaps are present so
`colourFromPresetName()` isn't consulted for this skin.
