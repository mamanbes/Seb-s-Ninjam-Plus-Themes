# UFO — alien abduction theme for NINJAMplus

Flying-saucer fader with a tractor beam, alien-head knob with a glowing
antenna that doubles as the value pointer, deep-space background with
a soft galactic band and scattered stars.

## What's in the folder

- `UFO/bg.png` — near-black space gradient, a diagonal blurred
  "galactic band" of light and dust, ~650 tiny stars plus a couple
  dozen brighter ones with a soft glow
- `UFO/fknob.png` — a UFO: metallic disc body, glowing blue dome,
  six colourful rim lights, and a translucent green tractor beam
  extending down through the rest of the fader box (with a few
  "beamed particle" specks drifting in it)
- `UFO/rknob.png` — a classic grey-green alien head, big black almond
  eyes, and a glowing pink antenna on top. The antenna is drawn in its
  neutral "straight up" pose — since the app rotates the whole bitmap
  at runtime, it swings around like a needle as you turn the knob,
  same trick as the eyeball's gaze in the Silly theme
- `UFO/skin.cfg` — near-black window/button colours, a green
  metronome flash (UFO-beam green)

## About "transparent" background

Same honest note as the Aurora skin, quickly repeated: `bg.png` is
still a fully opaque image — the app draws it filling the whole window
every time (`RectanglePlacement::fillDestination`, confirmed in your
`.cpp`), so a see-through PNG wouldn't reveal your actual desktop. What
I built instead is a background that reads as looking out into open
space, which is likely what "transparent... milky way/universe" was
really after visually. If you did specifically want the window itself
to be see-through to whatever's behind it, that's a real code change
(`setOpaque(false)` on the top-level window) and behaves inconsistently
once this is loaded as a VST3/AU plugin inside a DAW host — happy to
talk through it if you want to go that route anyway.

## About "bigger faders and knobs" — the honest version

This is the part I don't want to quietly half-do: **texture images
alone can't make these physically bigger on screen.** Both the fader
thumb and the knobs are drawn into a fixed-size box that the app
computes in `PluginEditor.cpp`, and `RectanglePlacement::centred` /
`fillDestination` will scale whatever image you give them *down* (or
up) to fit that box — never bigger than the box itself. I made the UFO
and alien fill their boxes as fully as the artwork allows, which is
the most "bigger" an image swap can do on its own.

To actually grow the boxes, here's exactly what controls each one
(all found directly in your `PluginEditor.cpp`, so these are real line
references, not guesses):

**Fader thumb** — in `FaderLookAndFeel::drawLinearSlider`:
```cpp
float thumbW = isVert ? juce::jmin(22.0f, (float)width * 0.68f) : 40.0f;
float thumbH = isVert ? 42.0f : (float)height * 0.95f;
```
Raise `22.0f` and `42.0f` (e.g. to `32.0f` / `60.0f`) to grow the UFO.

**REV/DLY knobs** — in the per-channel layout code:
```cpp
int revKnobSize = juce::jmin(24, juce::jmin(revKnobArea.getWidth(), revKnobArea.getHeight()));
int dlyKnobSize = juce::jmin(24, juce::jmin(dlyKnobArea.getWidth(), dlyKnobArea.getHeight()));
```
That `24` is the actual cap — bump it up (e.g. to `44`) and two things
happen at once: they get bigger, **and** they cross the `knobMinDim >=
40` threshold that gates bitmap-knob usage — which means the alien
head would start showing up on REV/DLY automatically, without needing
the `matchReleaseStyle` workaround I've mentioned in every previous
skin's README. That threshold check lives in
`CustomKnobLookAndFeel::drawRotarySlider`, for reference.

**Release knob** is already sized dynamically to fill whatever space
its panel column gives it (`knobArea` in the layout code) — it's
already "as big as it can be" without widening that whole column,
which is a slightly bigger layout change than the two above.

I didn't apply these for you this time, since our last file exchange
hit a build error and you asked to set code changes aside — happy to
send the exact patch (or a full replacement `PluginEditor.cpp` like
before) whenever you want to pick that back up.

## Installation

Copy `UFO/` into `textures/`, rebuild, pick "UFO" from the skin
dropdown. No source patch needed for colours — both bitmaps are
present so `colourFromPresetName()` isn't consulted for this skin.
