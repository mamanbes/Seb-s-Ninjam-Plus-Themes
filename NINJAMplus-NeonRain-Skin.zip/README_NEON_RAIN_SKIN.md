# Neon Rain / Cyberpunk — theme for NINJAMplus

Wet neon-lit city at night, a glowing dual-tone energy blade for the
fader, and a sci-fi HUD targeting-ring knob.

## What's in the folder

- `Neon Rain/bg.png` — near-black indigo city night, three soft distant
  neon glows (magenta / cyan / purple), a smoothly-graded "wet ground"
  lower third with blurred vertical colour reflections, fine diagonal
  rain streaks, and scattered coloured bokeh dots
- `Neon Rain/fknob.png` — an energy-blade fader: dark metal hilt with
  grip ridges and an emitter collar, blade glowing magenta at the base
  fading to cyan at the tip with a white-hot core line, tapered tip
- `Neon Rain/rknob.png` — a holographic HUD dial: dark glass centre,
  two concentric cyan/magenta rings, 32 radial tick marks, four corner
  targeting-brackets, and a glowing white pointer needle. Drawn in its
  neutral "straight up" pose — the app rotates the whole bitmap at
  runtime, so it reads the current value like a real gauge needle
- `Neon Rain/skin.cfg` — near-black indigo window/button colours, a
  hot-magenta metronome flash

## The usual rknob.png caveat

Same note as the last several skins with a real `rknob.png`: your
Release knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will show the HUD dial;
REV/DLY (smaller) will likely fall back to a plain vector knob, and
since `rknob.png` is present, `skin.cfg`'s `Knobs:` line is skipped,
so that fallback will be plain grey instead of themed. The fix is
either `matchReleaseStyle`/`forceImageKnob` on those two sliders, or
(bigger but reusable across every skin) raising the `revKnobSize`/
`dlyKnobSize` cap above 40 in the layout code, per the note in the
UFO theme's README.

## Installation

Copy `Neon Rain/` into `textures/`, rebuild, pick "Neon Rain" from the
skin dropdown. No source patch needed for colours — both bitmaps are
present so `colourFromPresetName()` isn't consulted for this skin.
