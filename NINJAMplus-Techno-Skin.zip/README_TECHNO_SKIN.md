# Techno — warehouse rave theme for NINJAMplus

Raw concrete warehouse at night, crossing laser beams, a perspective
floor grid, a moving-head spotlight fixture as the fader, and a
grippy hardware synth-knob with a classic acid-house smiley as the
rotary control.

## What's in the folder

- `Techno/bg.png` — near-black concrete base with heavier film-grain
  noise (industrial, unpolished, on purpose), two banks of crossing
  laser beams (acid green from one side, hot magenta from the other),
  glowing fixture points where the beams originate, and a rave-flyer
  style perspective floor grid across the bottom third
- `Techno/fknob.png` — a moving-head stage light: metal housing with a
  yoke and lens at the bottom of the fader box, a tapered acid-green
  beam with a white-hot core shooting up through the rest of the track
- `Techno/rknob.png` — a dark grippy hardware knob (grip ridges around
  the rim, alternating acid-green/magenta tick marks along a 270°
  travel arc, like a real synth or mixer knob) with a classic
  acid-house smiley face on the cap. A small acid-green dot sits at
  the top in the neutral pose as the rotation pointer, since a smiley
  doesn't have an obvious "direction" the way an eye's gaze or a
  tonearm does — the app rotates the whole bitmap at runtime, so the
  dot sweeps around normally as you turn the knob
- `Techno/skin.cfg` — near-black window/button colours, an acid-green
  metronome flash

## The usual rknob.png caveat

Same note as the last several skins with a real `rknob.png`: the
Release knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will show the smiley
knob; REV/DLY (smaller) will likely fall back to a plain vector knob,
and since `rknob.png` is present, `skin.cfg`'s `Knobs:` line is
skipped, so that fallback will be plain grey. Fix is
`matchReleaseStyle`/`forceImageKnob` on those two sliders, or the
reusable `revKnobSize`/`dlyKnobSize` cap increase from the UFO theme's
README.

## Installation

Copy `Techno/` into `textures/`, rebuild, pick "Techno" from the skin
dropdown. No source patch needed for colours — both bitmaps are
present so `colourFromPresetName()` isn't consulted for this skin.
