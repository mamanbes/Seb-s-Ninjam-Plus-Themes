# Jam In Peace — theme for NINJAMplus

Inspired by the youtube.com/@JamInPeace channel's live-jam-session,
peace-and-music spirit — tie-dye swirl background, a peace-sign hand
fader, and a rainbow-ringed peace-symbol knob.

## A quick note on how I approached this

You asked for "the peace sign / jam in peace logo" — I want to be
upfront about what I actually did rather than imply more than I
delivered: the peace symbol (circle + vertical bar + two diagonals)
and the two-finger "V" hand gesture are both generic, public-domain
pieces of iconography — nobody owns them, so using them freely is no
different from using a heart shape or a musical note. What I didn't
do is trace or reproduce the channel's actual specific logo artwork
(their particular drawn/stylized version of it, if they have one) —
that would be someone else's copyrighted work, and I don't reproduce
existing copyrighted art even in service of a fan-made skin. Their
name, "Jam In Peace," is just plain text here — that part's a direct,
literal match to what you asked for.

## What's in the folder

- `Jam In Peace/bg.png` — a tie-dye-style conic colour swirl (muted
  and darkened so your light-coloured UI text stays legible over it),
  a large faint peace-sign watermark centred in the frame, and the
  "JAM IN PEACE" wordmark beneath it
- `Jam In Peace/fknob.png` — a cartoon hand holding up a peace sign
  (index + middle finger), tie-dye-striped wristband, same cartoon
  proportions as the Silly theme's fist so it reads clearly at fader
  size
- `Jam In Peace/rknob.png` — the peace symbol itself, rendered in
  clean white on a dark glass disc, wrapped in a glowing rainbow
  conic-gradient ring. Since the peace symbol has no obvious
  "direction" the way an eye's gaze or a tonearm does, I added a small
  white notch dot at the top of the ring in its neutral pose — the
  app rotates the whole bitmap at runtime, so that dot sweeps around
  like a normal indicator as you turn the knob
- `Jam In Peace/skin.cfg` — deep violet window/button colours, a warm
  yellow metronome flash

## The usual rknob.png caveat

Same note as the last several skins with a real `rknob.png`: the
Release knob clears the `knobMinDim >= 40` threshold in
`CustomKnobLookAndFeel::drawRotarySlider` and will show the peace
symbol; REV/DLY (smaller) will likely fall back to a plain vector
knob, and since `rknob.png` is present, `skin.cfg`'s `Knobs:` line is
skipped, so that fallback will be plain grey. Fix is `matchReleaseStyle`
/`forceImageKnob` on those two sliders, or the reusable
`revKnobSize`/`dlyKnobSize` cap increase from the UFO theme's README.

## Installation

Copy `Jam In Peace/` into `textures/`, rebuild, pick "Jam In Peace"
from the skin dropdown. No source patch needed for colours — both
bitmaps are present so `colourFromPresetName()` isn't consulted for
this skin.
